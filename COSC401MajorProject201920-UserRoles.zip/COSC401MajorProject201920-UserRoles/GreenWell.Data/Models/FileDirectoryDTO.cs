﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GreenWell.Data.Models
{
    public class FileDirectoryDTO
    {
        public string path { get; set; }
    }
}
