# COSC401MajorProject201920
This system was created by the Fall 2019 COSC 401 Software Startup Simulator Capstone class to create Greenwell State Park’s database. This system will be an internet hosted database used by board members and trustees of the Greenwell Foundation. The intended use of this database is to replace their current content distribution and organization system with a centralized, proprietary solution.


Members:
Professor: Dr. Lindsay Jamieson
Project Leader: Ali Yar Khan '20
Quality Assurance and Documentation Team: Matt Heitmann '20 - Lead, Raymond Martin '21, Jacob Hamilton '20, Alexander De La Paz '21, Abby Mattingly '21, Cooper Rice '21
Research and Development Team: Nick True ‘20 - Lead, Matt Manoly ‘20 - Lead, Yousef Mohammed ‘20, Joey Orr ‘20, Isaac Freshour ‘20, Mason Humphrey ‘20, Zachary Taylor ‘20, Patrick Romero '21, Thomas Walker '21, Maddie White '20

